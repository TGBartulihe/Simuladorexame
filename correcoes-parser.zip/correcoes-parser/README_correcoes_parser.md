# Correções no parser — diagnóstico e arquivos prontos

## O que foi encontrado

Three bugs na extração de PDF, todos confirmados contra dados reais do
seu `simuladorexame.db` (não são hipotéticos — cada um foi reproduzido
com um caso concreto do banco antes de eu escrever a correção):

| # | Bug | Sintoma no banco | Causa | Arquivo |
|---|---|---|---|---|
| 1a | Tabela de cotações no INÍCIO de um grupo capturada como enunciado da questão 1 | 22 questões com `statement` = só números + "Cotação (em pontos)" | `QUESTION_PATTERN`/`QUESTION_START` casam com qualquer linha "N. " — não distinguem de uma grade de cotações que também começa com "1. " | `parse_questions.py`, `extract_contexts.py` |
| 1b | Tabela de cotações no FIM da prova (depois de "FIM") colada ao final da ÚLTIMA questão do último grupo | Confirmado lendo o PDF original (Biologia e Geologia, 2025, 1.ª fase): a questão "GRUPO III, item 4" tinha enunciado válido com a tabela de cotações inteira concatenada depois — não há questão "5" para servir de limite | Nenhum módulo cortava o texto no marcador "FIM"; o anexo de cotações ficava dentro do texto do último grupo | `parse_groups.py` |
| 2 | Gabarito de questões "irmãs" perdido (ex: questão 13 fica sem `criteria_text` próprio); e questões deslocadas por um falso "número de questão" | 7 blocos no banco, cobrindo 18+ questões, com o critério de várias questões colado num único registro; mais um efeito cascata onde a entrada do critério da questão N continha, na verdade, o conteúdo da questão N+1 | `ITEM_PATTERN` só encontrava 1 match por bloco quando o PDF listava vários números na mesma linha ("Item 12. 13."); e, ao testar contra o PDF real, a linha "8 pontos" (cotação de uma questão anterior, impressa isolada por causa dos pontos de preenchimento do PDF) era lida como "questão número 8" | `parse_criteria.py` |
| 3 | Texto com glifos sem mapeamento Unicode (ex: `/g14/g14/g16/g32`) | Pelo menos 1 trecho ilegível visto na auditoria, provavelmente em fórmulas matemáticas/físicas | `_looks_valid()` só audita tamanho total + 3 palavras-chave — não detecta corrupção localizada de fonte simbólica | `extract_pdf.py` |
| **4** | **Questões inteiras desaparecendo silenciosamente quando o enunciado menciona "Instituto" ou "IAVE" de passagem** | Confirmado lendo o texto bruto pós-`clean_text()`: a questão "GRUPO III, item 4" (que menciona "Instituto Português do Mar e da Atmosfera") teve sua PRIMEIRA LINHA inteira removida, incluindo o "4." que o parser de questões precisa para detectá-la — a questão não aparecia nem como statement corrompido, simplesmente não existia | `remove_headers()` usa os padrões `"IAVE.*"` e `"INSTITUTO.*"` SEM ancorar ao início da linha — qualquer linha que contenha essas palavras em QUALQUER posição é descartada inteira, não só o timbre institucional do cabeçalho | `clean_text.py` |

O bug 4 é o mais sério dos quatro: ele não produz um sintoma óbvio como
"statement esquisito" — a questão simplesmente não existe em lugar
nenhum, nem na tabela `questions`, nem como erro visível. Só foi
encontrado comparando manualmente a saída do parser contra o PDF
original, questão por questão. **Isto significa que pode haver outras
questões, em outros exames, perdidas da mesma forma** — qualquer
enunciado que mencione "Instituto" (de pesquisa, de ensino, etc.) ou a
sigla "IAVE" de passagem teria a mesma linha removida silenciosamente.
Vale considerar isso como motivo extra para reprocessar do zero (ver
seção sobre reprocessar vs. remendar, abaixo) — não há como saber quantas
questões foram afetadas sem reprocessar e comparar contagens.

O bug 1b e o bug 4 só foram encontrados DEPOIS da primeira rodada de
correções, ao rodar o teste piloto (`pilot_test_single_exam.py`) contra
um par real de PDFs e comparar a saída, questão por questão, com o PDF
original anexado na conversa. A lição prática disto: heurísticas de
parser de texto livre (regex sobre PDF extraído) têm uma cauda longa de
casos extremos que só aparecem testando contra documentos reais — por
isso o pacote inclui o script de teste piloto, para você poder repetir
esse processo com outros exames antes de reprocessar o lote completo.

**Nota sobre o bug 2, revisado duas vezes**: a primeira versão desta
correção assumia que "Item 12. 13." e "Versão 1 (C) (D)" viriam cada um
numa única linha — e funcionava nos meus testes manuais. Testando contra
o texto real extraído do PDF (via `pilot_test_single_exam.py` salvando
`debug_pilot_output/criteria_raw.txt`), descobri que o PDF real extrai
CADA número e CADA letra em sua própria linha separada ("Item" numa
linha, "12." na linha seguinte, "13." na seguinte, etc.). A versão atual
do arquivo já reflete isso — não é preciso fazer mais nada, mas se você
notar números de questão ainda desalinhados depois de reprocessar, vale
repetir esse mesmo processo de comparação com `criteria_raw.txt` antes de
assumir que é um bug novo.

Também testei a hipótese de mojibake (texto com acentos corrompidos tipo
"VersÃ£o") depois de ver isso no terminal do PowerShell — mas confirmei,
lendo o arquivo direto em Python, que o texto real em disco está correto
("Versão", "Critérios", acentuação perfeita). A corrupção que aparecia no
terminal era um artefato de como o PowerShell/clipboard exibia certos
bytes, não um problema real nos dados. Don't repita esse teste a menos
que veja sinais de mojibake DENTRO do Python (não só no terminal).

Bônus: os dois primeiros bugs também revelaram que a regra "o que conta
como início de questão" estava **duplicada** em dois arquivos
(`parse_questions.py` e `extract_contexts.py`) com regex quase — mas não
exatamente — iguais. Isso por si só já é um risco (corrigir um sem o
outro faz os módulos discordarem). Criei `question_boundaries.py` para
unificar isso.

## Arquivos neste pacote

- **`question_boundaries.py`** — NOVO. Funções compartilhadas
  `find_question_starts()` e `truncate_at_exam_end()`, usadas pelos
  arquivos abaixo. Corrige os bugs 1a e 1b e remove a duplicação de regex.
- **`clean_text_corrigido.py`** → substitui `parser/utils/clean_text.py`
  (corrige o bug 4 — o mais sério dos quatro, ver acima)
- **`parse_groups_corrigido.py`** → substitui `parser/parse/parse_groups.py`
  (corrige o bug 1b — trunca o anexo de cotações do fim da prova)
- **`parse_questions_corrigido.py`** → substitui `parser/parse/parse_questions.py`
- **`extract_contexts_corrigido.py`** → substitui `parser/extract/extract_contexts.py`
- **`parse_criteria_corrigido.py`** → substitui `parser/parse/parse_criteria.py`
  (corrige o bug 2 — gabarito de questões irmãs)
- **`extract_pdf_corrigido.py`** → substitui `parser/extract/extract_pdf.py`
  (corrige o bug 3 — detecta e reporta corrupção de glifo, por página)
- **`batch_extract_corrigido.py`** → substitui `parser/extract/batch_extract.py`
  (imprime um resumo dos documentos com glifo corrompido ao final do lote)

Todos testados isoladamente contra casos reproduzidos a partir do PDF
real (não apenas lidos e "parecem corretos" — reconstruí o texto exato
do GRUPO III de `EX-BG702-F1-2025-V1_net.pdf` + critério, e confirmei
que as 4 questões saem limpas, sem a tabela de cotações colada e sem a
questão 4 desaparecer).

## ⚠️ Decisão que você precisa tomar: reprocessar ou remendar

Os bugs #1 e #2 estão na **extração a partir do PDF**. O
`simuladorexame.db` atual já tem o texto extraído gravado em
`documents.extracted_text` — substituir os arquivos do parser **não
corrige retroativamente** o que já foi processado. Existem duas
estratégias, e elas não se excluem:

### Estratégia A — reprocessar do zero (corrige a causa raiz)

```bash
# depois de substituir os 5 arquivos do parser pelos corrigidos:
python -m scripts.process_parser_v2
```

Isso reconstrói `questions`, `criteria`, `choices`, etc. a partir dos
PDFs originais, agora com a lógica corrigida. **Importante**: isso
também vai apagar o trabalho já feito pelos scripts 01/02 (gabarito
resolvido por regex/LLM, que vimos na conversa anterior) — porque
`clear_v2_tables()` dentro de `process_parser_v2.py` limpa essas tabelas
antes de reprocessar. Depois de reprocessar, você precisaria rodar os
scripts 01/02/03 de novo (mas agora parte de uma base mais limpa — menos
casos vão cair em "sem padrão reconhecível" porque o bug #2 não estará
mais misturando o critério de duas questões).

Os PDFs originais não estão neste banco (o README do repo confirma:
"PDFs originais: não versionados") — você precisa ter o diretório de
PDFs de origem disponível para rodar isto.

### Estratégia B — remendar só o banco atual (mais rápido, não resolve a causa)

Se você não tiver os PDFs à mão agora, ou quiser primeiro terminar a
rodada do script 02 que já está em andamento: os scripts 01/02/03 da
conversa anterior já contornam os sintomas desses bugs no nível dos
dados (ex: o script 01 resolve a tabela "Item 12. 13." por regex depois
do fato; o export marca `statementCorrompido` para as 22 questões do
bug #1). Isso continua funcionando — só não impede que o **próximo**
exame que você processar tenha os mesmos problemas.

### Minha recomendação

Termine a rodada atual do script 02 (já está em andamento, não vale
interromper). Depois, se você tiver os PDFs originais disponíveis, vale
a pena reprocessar do zero pelo menos uma vez com o parser corrigido —
isso deve reduzir bastante a fração de questões que caem em "sem padrão
reconhecível"/"sem resposta confiável" hoje, porque uma parte real desses
casos (confirmamos isso na sua rodada de teste com `qid=106` e `qid=69`,
onde o próprio LLM apontou "o critério se refere a outra questão") é
causada exatamente pelo bug #2.

## O que eu NÃO consegui validar

Não tenho acesso aos PDFs originais nem aos módulos
`parser.database.repository.Repository`, `parser.services.document_service.DocumentService`,
`parser.models` (`Group`, `Question`, `Page`), `parser.utils.clean_text`,
`parser.utils.split_pages`, `parser.utils.match_questions`, ou
`parser.utils.extract_choices` — só vi as assinaturas que eles expõem,
inferidas de como são chamados em `pipeline.py`/`parse_questions.py`.
Testei cada correção isoladamente com mocks mínimos desses módulos, mas
**não roda o pipeline completo de ponta a ponta** antes de você aplicar.
Recomendo testar num PDF só (ou um subconjunto pequeno) antes de rodar
`process_parser_v2` no lote completo de 396 documentos.
